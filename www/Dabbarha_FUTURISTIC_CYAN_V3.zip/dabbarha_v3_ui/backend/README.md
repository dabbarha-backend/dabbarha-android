# Backend
Set environment variables on Render:
- OPENAI_API_KEY = your server-side secret
- OPENAI_MODEL = gpt-5.6-sol
Start command: node server.js
Build command: npm install
