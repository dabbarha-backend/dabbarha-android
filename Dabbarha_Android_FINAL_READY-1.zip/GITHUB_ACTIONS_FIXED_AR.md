# إصلاح GitHub Actions لتطبيق دبّرها

هذه النسخة أصلحت مشكلة `Setup Android SDK`:
- تثبيت Android SDK عبر `android-actions/setup-android@v3`.
- تثبيت Android 36 وBuild Tools 36.0.0.
- استخدام Java 17 وGradle 8.7.
- بناء Debug APK وRelease APK وRelease AAB.
- حفظ الملفات كـArtifacts داخل GitHub Actions.

## الاستخدام
1. ارفع محتويات هذا المشروع إلى مستودع `dabbarha-android` مع استبدال الملفات القديمة.
2. افتح تبويب **Actions**.
3. اختر **Build Dabbarha Android**.
4. اضغط **Run workflow**.
5. بعد نجاح البناء، افتح التشغيل الناجح ثم قسم **Artifacts**.
6. حمّل `dabbarha-release-apk` للتجربة و`dabbarha-release-aab` للنشر.

ملاحظة: ملف AAB الناتج هنا Release غير موقّع بمفتاحك الشخصي. نشره في Google Play يتطلب توقيع التطبيق/إعداد Play App Signing.
