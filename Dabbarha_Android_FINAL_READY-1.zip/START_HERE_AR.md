# دبّرها — ابدأ من هنا

1. ارفع **كل محتويات هذا المجلد** إلى مستودع `dabbarha-android` في GitHub (وليس ملف ZIP نفسه).
2. اضغط Commit changes.
3. افتح Actions ثم Build Dabbarha Android ثم Run workflow.
4. بعد نجاح Build، افتح صفحة التشغيل ثم Artifacts ونزّل `dabbarha-debug-apk`.

ملاحظة: نسخة release الحالية غير موقعة؛ النشر على Google Play يحتاج توقيع AAB لاحقًا.
ملاحظة أمنية: لا تضع مفتاح OpenAI داخل تطبيق Android؛ المفتاح يبقى في الخادم.
