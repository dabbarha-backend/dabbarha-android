# نشر Backend بسرعة

هذا المشروع يحتوي `Dockerfile` و`render.yaml` لتسهيل النشر على خدمة استضافة تدعم Docker.

بعد النشر:
1. أضف `OPENAI_API_KEY` كـ Secret/Environment Variable في الخادم.
2. اترك `OPENAI_MODEL` على `gpt-5.6-luna` أو غيّره حسب إعدادك.
3. تأكد أن `/health` يرجع حالة سليمة.
4. خذ رابط HTTPS الذي تعطيه منصة الاستضافة.
5. ضع الرابط في `app/src/main/res/values/strings.xml` داخل `backend_url`.
6. ابنِ التطبيق واختبر النص والصورة من هاتف حقيقي.

لا تضع مفتاح OpenAI داخل Android أو GitHub.
