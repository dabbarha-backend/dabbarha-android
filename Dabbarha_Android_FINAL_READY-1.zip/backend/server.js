import express from 'express';
import cors from 'cors';

const app = express();

const RATE_LIMIT_WINDOW_MS = Number(process.env.RATE_LIMIT_WINDOW_MS || 60000);
const RATE_LIMIT_MAX = Number(process.env.RATE_LIMIT_MAX || 20);
const rateBuckets = new Map();

function rateLimit(req, res, next) {
  const key = req.ip || req.headers['x-forwarded-for'] || 'unknown';
  const now = Date.now();
  let bucket = rateBuckets.get(key);
  if (!bucket || now - bucket.start >= RATE_LIMIT_WINDOW_MS) {
    bucket = { start: now, count: 0 };
    rateBuckets.set(key, bucket);
  }
  bucket.count += 1;
  if (bucket.count > RATE_LIMIT_MAX) {
    return res.status(429).json({ error: 'rate_limit_exceeded' });
  }
  next();
}


app.use(cors());
app.use(express.json({limit:'8mb'}));
app.use('/privacy', express.static(new URL('./public', import.meta.url).pathname));

const key = process.env.OPENAI_API_KEY;
const model = process.env.OPENAI_MODEL || 'gpt-5.6-luna';

app.get('/health', (_, res) => res.json({ok:true, service:'dabbarha-ai'}));

app.post('/api/analyze', rateLimit, async (req, res) => {
  try {
    const text = String(req.body?.text || '').trim();
    if (!text) return res.status(400).json({error:'text_required'});
    if (!key) return res.status(500).json({error:'OPENAI_API_KEY_not_configured'});

    const r = await fetch('https://api.openai.com/v1/responses', {
      method:'POST',
      headers:{'Content-Type':'application/json','Authorization':`Bearer ${key}`},
      body:JSON.stringify({
        model,
        input:[{
          role:'system',
          content:[{type:'input_text',text:'أنت مساعد تطبيق دبّرها. حلّل مشكلة المستخدم بالعربية، صنّفها، ثم أعط خطة عملية قصيرة من 3 إلى 7 خطوات. لا تدّعي تنفيذ أشياء لم تنفذها. إذا كانت المشكلة طبية أو قانونية أو مالية عالية المخاطر، نبّه المستخدم إلى ضرورة الرجوع لمختص.'}]
        },{
          role:'user',
          content:[{type:'input_text',text}]
        }]
      })
    });
    const data = await r.json();
    if (!r.ok) return res.status(r.status).json({error:data?.error?.message || 'openai_error'});
    res.json({text:data.output_text || ''});
  } catch (e) {
    res.status(500).json({error:e.message || 'server_error'});
  }
});



app.post('/api/analyze-image', rateLimit, async (req, res) => {
  try {
    const image = String(req.body?.image || '').trim();
    if (!image.startsWith('data:image/')) return res.status(400).json({error:'image_required'});
    if (!key) return res.status(500).json({error:'OPENAI_API_KEY_not_configured'});
    const r = await fetch('https://api.openai.com/v1/responses', {
      method:'POST',
      headers:{'Content-Type':'application/json','Authorization':`Bearer ${key}`},
      body:JSON.stringify({
        model,
        input:[{
          role:'system',
          content:[{type:'input_text',text:'أنت مساعد تطبيق دبّرها. افحص صورة المستند. استخرج النص المهم كما يظهر، ثم اشرح للمستخدم نوع المستند ومعناه والخطوات المطلوبة. إذا كانت الصورة غير واضحة قل ذلك بوضوح ولا تخمّن البيانات الشخصية أو الأرقام. استخدم العربية الواضحة.'}]
        },{
          role:'user',
          content:[{type:'input_text',text:'اقرأ المستند في الصورة واشرحه خطوة بخطوة.'},{type:'input_image',image_url:image}]
        }]
      })
    });
    const data=await r.json();
    if(!r.ok) return res.status(r.status).json({error:data?.error?.message||'openai_error'});
    res.json({text:data.output_text||''});
  } catch(e){res.status(500).json({error:e.message||'server_error'});}
});

app.listen(process.env.PORT || 8080, '0.0.0.0', () => console.log('Dabbarha AI backend running'));
