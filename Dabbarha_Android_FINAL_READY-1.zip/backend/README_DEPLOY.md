# نشر Backend — دبّرها v7

- Node.js 18+
- ضع `OPENAI_API_KEY` في الخادم فقط.
- استخدم `OPENAI_MODEL=gpt-5.6-luna`.
- شغّل `npm install` ثم `npm start`.
- اختبر `/health` ثم `/api/analyze` و`/api/analyze-image`.
- غيّر `backend_url` في `app/src/main/res/values/strings.xml` إلى رابط HTTPS الحقيقي.

قبل النشر العام: HTTPS، rate limiting، authentication مناسب، وعدم تسجيل مفاتيح API أو صور المستندات، مع سياسة واضحة للاحتفاظ والحذف.
