package com.dabbarha.app;

import android.app.*;
import android.content.*;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL="dabbarha_reminders";
    @Override public void onReceive(Context context, Intent intent){
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel(CHANNEL,"تذكيرات دبّرها",NotificationManager.IMPORTANCE_DEFAULT);nm.createNotificationChannel(ch);}
        Intent open=new Intent(context,MainActivity.class); open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi=PendingIntent.getActivity(context,101,open,PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(context,CHANNEL):new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("دبّرها 🔔").setContentText("حان وقت مراجعة خطتك والخطوة التالية.").setContentIntent(pi).setAutoCancel(true);
        nm.notify(101,b.build());
    }
}
