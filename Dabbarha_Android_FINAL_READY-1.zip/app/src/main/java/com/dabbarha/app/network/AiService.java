package com.dabbarha.app.network;

import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;

/** Secure client: API keys stay on the backend, never in the APK. */
public class AiService {
    public interface Callback { void onSuccess(String response); void onError(Exception error); }
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private final String baseUrl;
    public AiService(String baseUrl){this.baseUrl=baseUrl.replaceAll("/$","");}
    private String post(String path, JSONObject body) throws Exception {
        URL url=new URL(baseUrl+path); HttpURLConnection c=(HttpURLConnection)url.openConnection();
        c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(90000);
        c.setRequestProperty("Content-Type","application/json; charset=UTF-8"); c.setDoOutput(true);
        try(OutputStream os=c.getOutputStream()){os.write(body.toString().getBytes(StandardCharsets.UTF_8));}
        int code=c.getResponseCode(); InputStream is=code>=200&&code<300?c.getInputStream():c.getErrorStream();
        StringBuilder out=new StringBuilder(); try(BufferedReader br=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8))){String l;while((l=br.readLine())!=null)out.append(l);}
        if(code<200||code>=300) throw new IOException(out.toString());
        return new JSONObject(out.toString()).optString("text","");
    }
    public void analyze(String text, Callback cb){executor.execute(()->{try{JSONObject b=new JSONObject().put("text",text);cb.onSuccess(post("/api/analyze",b));}catch(Exception e){cb.onError(e);}});}
    public void analyzeImage(String dataUrl, Callback cb){executor.execute(()->{try{JSONObject b=new JSONObject().put("image",dataUrl);cb.onSuccess(post("/api/analyze-image",b));}catch(Exception e){cb.onError(e);}});}
}
