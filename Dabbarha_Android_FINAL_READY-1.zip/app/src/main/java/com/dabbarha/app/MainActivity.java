package com.dabbarha.app;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.File;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.view.*;
import android.widget.*;
import java.util.*;
import com.dabbarha.app.network.AiService;

public class MainActivity extends Activity {
    // Change this to your deployed HTTPS backend before release.
    private static final String AI_BASE_URL = "https://YOUR-DABBARHA-BACKEND.example";
    private final AiService aiService = new AiService(getString(R.string.backend_url));
    private LinearLayout content;
    private EditText problem;
    private TextView result, saved;
    private final int BLUE = Color.rgb(37, 99, 235);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        build();
    }

    private TextView tv(String s, float size) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(22,32,51));
        t.setPadding(16,12,16,12); t.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        return t;
    }
    private Button btn(String s) { Button b=new Button(this); b.setText(s); b.setTextSize(14); return b; }

    private void build() {
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
        LinearLayout header=new LinearLayout(this); header.setOrientation(LinearLayout.VERTICAL); header.setPadding(18,20,18,22); header.setBackgroundColor(Color.rgb(16,32,91));
        TextView h=tv("دبّرها 👋",30); h.setTextColor(Color.WHITE); h.setGravity(Gravity.RIGHT);
        TextView sub=tv("مشكلتك؟ خلّينا نحوّلها لخطة واضحة.",16); sub.setTextColor(Color.WHITE); sub.setGravity(Gravity.RIGHT);
        header.addView(h); header.addView(sub); root.addView(header);

        ScrollView scroll=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(14,14,14,90); scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        problem=new EditText(this); problem.setHint("اكتب مشكلتك هنا..."); problem.setGravity(Gravity.TOP|Gravity.RIGHT); problem.setTextSize(17); problem.setMinLines(4); problem.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        content.addView(problem,new LinearLayout.LayoutParams(-1,260));

        LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
        Button voice=btn("🎤 صوت"); voice.setOnClickListener(v->voice());
        Button photo=btn("📷 اقرأ مستند"); photo.setOnClickListener(v->camera());
        Button solve=btn("✨ دبّرها"); solve.setOnClickListener(v->solve());
        actions.addView(voice,new LinearLayout.LayoutParams(0,-2,1)); actions.addView(photo,new LinearLayout.LayoutParams(0,-2,1)); actions.addView(solve,new LinearLayout.LayoutParams(0,-2,1)); content.addView(actions);

        content.addView(tv("⚡ أدوات ذكية",20));
        String[][] tools={{"💰","ميزانيتي","أريد تنظيم ميزانيتي ومصروفي"},{"📚","دراستي","أريد خطة للدراسة والامتحان"},{"💼","وظيفتي","أريد تجهيز CV والبحث عن وظيفة"},{"📄","مستنداتي","أريد فهم هذا المستند"},{"🌐","الترجمة","أريد ترجمة هذا النص"},{"🛒","مشترياتي","أريد مساعدتي في اختيار شراء مناسب"}};
        for(String[] a:tools){Button x=btn(a[0]+"  "+a[1]); x.setOnClickListener(v->{problem.setText(a[2]); problem.requestFocus();}); content.addView(x);}

        content.addView(tv("📌 الخطط المحفوظة",20)); saved=tv(loadSaved(),15); content.addView(saved);
        Button save=btn("📌 حفظ آخر خطة"); save.setOnClickListener(v->savePlan()); content.addView(save);
        Button notify=btn("🔔 تفعيل تذكير يومي"); notify.setOnClickListener(v->scheduleReminder()); content.addView(notify);
        Button clear=btn("🗑️ مسح الخطة المحفوظة"); clear.setOnClickListener(v->{getPreferences(0).edit().remove("plan").apply(); saved.setText(loadSaved());}); content.addView(clear);
        content.addView(tv("نسخة MVP: التحليل المحلي تجريبي. لنسخة الإنتاج سنوصل الذكاء الاصطناعي وقراءة المستندات بخادم آمن.",13));
        setContentView(root);
    }

    private void solve() {
        String v=problem.getText().toString().trim();
        if(v.isEmpty()){problem.setError("اكتب المشكلة أولاً");return;}
        if(result!=null) content.removeView(result);
        result=tv("🤖 جاري تحليل مشكلتك...",16); result.setBackgroundColor(Color.rgb(245,247,250)); content.addView(result,2);
        aiService.analyze(v, new AiService.Callback(){
            @Override public void onSuccess(String response){ runOnUiThread(() -> {
                result.setText("🤖 دبّرها لك\n\n" + response);
                Toast.makeText(MainActivity.this,"تم التحليل بالذكاء الاصطناعي ✅",Toast.LENGTH_SHORT).show();
            });}
            @Override public void onError(Exception error){ runOnUiThread(() -> {
                result.setText(localPlan(v));
                Toast.makeText(MainActivity.this,"تعذر الاتصال بالخادم؛ استخدمنا الخطة المحلية.",Toast.LENGTH_LONG).show();
            });}
        });
    }

    private String localPlan(String v) {
        ArrayList<String> p=new ArrayList<>(); String cat="مشكلة يومية";
        if(v.matches("(?s).*(امتحان|دراسة|مذاكر|مدرسة).*")){cat="دراسة";p.addAll(Arrays.asList("حدد المواد والمواضيع المطلوبة","قسّم الأيام على المواد","نفّذ جلسة تركيز يومية","حل أسئلة تدريبية وسجل الأخطاء","اختبر نفسك وراجع نقاط الضعف"));}
        else if(v.matches("(?s).*(فلوس|مال|مصروف|ميزان|راتب).*")){cat="مال شخصي";p.addAll(Arrays.asList("اكتب الدخل والمبلغ المتاح","سجل المصروفات الضرورية","ضع سقفاً للمصروف","خفّض غير الضروري","راجع الميزانية بعد 7 أيام"));}
        else if(v.matches("(?s).*(وظيف|عمل|CV|سيرة|شركة).*")){cat="عمل";p.addAll(Arrays.asList("حدد الوظيفة المستهدفة","جهّز سيرة ذاتية واضحة","اكتب رسالة تقديم","قدّم لفرص موثوقة","سجل الطلبات وتابع الردود"));}
        else {p.addAll(Arrays.asList("عرّف المشكلة والنتيجة المطلوبة","قسّمها إلى أجزاء صغيرة","ابدأ بأبسط خطوة الآن","راجع ما تم إنجازه","حدد الخطوة التالية بموعد واضح"));}
        StringBuilder s=new StringBuilder("التصنيف: "+cat+"\n\n🗺️ الخطة المقترحة:\n");
        for(int i=0;i<p.size();i++)s.append("\n").append(i+1).append(". ").append(p.get(i));
        return s.toString();
    }

    private void savePlan(){if(result==null){Toast.makeText(this,"أنشئ خطة أولاً",Toast.LENGTH_SHORT).show();return;} getPreferences(0).edit().putString("plan",result.getText().toString()).apply();saved.setText(loadSaved());Toast.makeText(this,"تم الحفظ 📌",Toast.LENGTH_SHORT).show();}
    private String loadSaved(){return getPreferences(0).getString("plan","لا توجد خطط محفوظة حتى الآن.");}

    private void voice(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},22);return;}
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ar");
        try{startActivityForResult(i,10);}catch(Exception e){Toast.makeText(this,"ميزة الصوت غير متاحة على هذا الجهاز.",Toast.LENGTH_LONG).show();}
    }
    @Override protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);
        if(r==10&&c==RESULT_OK&&d!=null){ArrayList<String>a=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(a!=null&&!a.isEmpty())problem.setText(a.get(0));}
        if(r==11&&c==RESULT_OK&&d!=null&&d.getExtras()!=null){
            Object raw=d.getExtras().get("data");
            if(raw instanceof Bitmap){ analyzeCapturedImage((Bitmap)raw); }
        }
    }

    private void analyzeCapturedImage(Bitmap bitmap){
        if(result!=null) content.removeView(result);
        result=tv("📷🤖 جاري قراءة المستند وفهمه...",16); result.setBackgroundColor(Color.rgb(245,247,250)); content.addView(result,2);
        Bitmap scaled=bitmap;
        int max=1400;
        if(bitmap.getWidth()>max){ int h=(int)(bitmap.getHeight()*(max/(double)bitmap.getWidth())); scaled=Bitmap.createScaledBitmap(bitmap,max,h,true); }
        ByteArrayOutputStream baos=new ByteArrayOutputStream(); scaled.compress(Bitmap.CompressFormat.JPEG,82,baos);
        String dataUrl="data:image/jpeg;base64,"+Base64.encodeToString(baos.toByteArray(),Base64.NO_WRAP);
        aiService.analyzeImage(dataUrl,new AiService.Callback(){
            public void onSuccess(String response){runOnUiThread(()->{result.setText("📄 دبّرها قرأت المستند:

"+response);Toast.makeText(MainActivity.this,"تم تحليل المستند بالذكاء الاصطناعي ✅",Toast.LENGTH_LONG).show();});}
            public void onError(Exception e){runOnUiThread(()->{result.setText("تعذر قراءة المستند الآن. جرّب صورة أوضح أو اكتب النص يدويًا.

"+e.getMessage());Toast.makeText(MainActivity.this,"تعذر الاتصال بالخادم.",Toast.LENGTH_LONG).show();});}
        });
    }

    private void camera(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.CAMERA},21);return;}
        Intent i=new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        if(i.resolveActivity(getPackageManager())!=null)startActivityForResult(i,11); else Toast.makeText(this,"الكاميرا غير متاحة.",Toast.LENGTH_SHORT).show();
    }

    private void scheduleReminder(){
        if(Build.VERSION.SDK_INT>=31){AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);if(!am.canScheduleExactAlarms()){startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM));return;}}
        Intent intent=new Intent(this, ReminderReceiver.class);
        PendingIntent pi=PendingIntent.getBroadcast(this,100,intent,PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE); Calendar cal=Calendar.getInstance(); cal.add(Calendar.MINUTE,1);
        if(Build.VERSION.SDK_INT>=23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi); else am.setExact(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi);
        Toast.makeText(this,"تم ضبط أول تذكير بعد دقيقة 🔔",Toast.LENGTH_LONG).show();
    }

    private void analyzeCapturedImageUri(Uri uri) {
        showResult("📷🤖 جاري قراءة المستند بجودة كاملة...");
        new Thread(() -> {
            try {
                Bitmap original;
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    original = BitmapFactory.decodeStream(in);
                }
                if (original == null) throw new IllegalStateException("image_decode_failed");

                int maxWidth = 1800;
                Bitmap bitmap = original;
                if (original.getWidth() > maxWidth) {
                    int h = (int) (original.getHeight() * (maxWidth / (float) original.getWidth()));
                    bitmap = Bitmap.createScaledBitmap(original, maxWidth, h, true);
                }

                ByteArrayOutputStream out = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out);
                String b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
                String dataUrl = "data:image/jpeg;base64," + b64;

                runOnUiThread(() -> aiService.analyzeImage(dataUrl, new AiService.Callback() {
                    @Override public void onSuccess(String response) {
                        showResult("📄 دبّرها قرأت المستند:\n\n" + response);
                    }
                    @Override public void onError(String error) {
                        showResult("تعذر فهم المستند الآن. تأكد من وضوح الصورة واتصال الإنترنت ثم جرّب مرة أخرى.");
                    }
                }));
            } catch (Exception e) {
                runOnUiThread(() -> showResult("تعذر تجهيز صورة المستند. جرّب صورة أوضح."));
            }
        }).start();
    }

}
