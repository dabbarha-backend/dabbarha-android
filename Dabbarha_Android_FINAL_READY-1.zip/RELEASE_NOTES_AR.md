# نسخة Release 1.1.0

- تجهيز إعدادات Android للنشر في Google Play.
- تحديث targetSdk وcompileSdk إلى 36 لمتطلبات Google Play الحالية.
- رفع versionCode إلى 2 وversionName إلى 1.1.0.
- ضبط رابط الخادم على HTTPS.
- تحديث سياسة الخصوصية لتوضيح معالجة النصوص والصور والصوت وخدمات الذكاء الاصطناعي.
- إضافة بيانات متجر Google Play وقائمة فحص النشر.
