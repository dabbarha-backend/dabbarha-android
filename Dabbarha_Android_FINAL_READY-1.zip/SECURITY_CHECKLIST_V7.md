# دبّرها v7 — قائمة قبل النشر

تم:
- تصوير Full Resolution عبر FileProvider بدل thumbnail.
- رابط Backend قابل للتغيير من strings.xml.
- مفتاح OpenAI يبقى في Backend.

متبقّي:
- نشر Backend على HTTPS.
- rate limiting/auth.
- اختبار مستندات عربية حقيقية وأجهزة متعددة.
- مراجعة الخصوصية وحذف/عدم الاحتفاظ بالصور.
- بناء AAB موقّع واختباره قبل Google Play.
