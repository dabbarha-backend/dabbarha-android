# دبّرها — Android + GitHub Actions

هذه النسخة مرتبة لتسمح ببناء التطبيق من GitHub Actions بدون كمبيوتر محلي.

- التطبيق: `com.dabbarha.app`
- الإصدار: `1.1.0`
- الإصدار الداخلي: `2`
- Target SDK: `36`
- Backend: `https://fthy.onrender.com`

ابدأ برفع **محتويات المشروع** إلى جذر مستودع `dabbarha-android`، وليس ملف ZIP نفسه.
