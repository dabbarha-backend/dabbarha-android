# دبّرها — خطة الإطلاق

## تم إنجازه في v7
- Android Studio project.
- واجهة عربية RTL.
- إدخال المشكلة وتحليلها عبر Backend.
- تصوير المستند بصورة كاملة عبر FileProvider.
- إرسال صورة المستند إلى `/api/analyze-image`.
- رابط Backend منفصل في `strings.xml`.
- مفتاح OpenAI لا يدخل تطبيق Android.

## آخر متطلبات قبل Google Play
1. نشر Backend على HTTPS حقيقي.
2. ضبط `backend_url` في `strings.xml`.
3. وضع `OPENAI_API_KEY` في بيئة الخادم فقط.
4. إضافة rate limiting ومصادقة/حماية مناسبة للـAPI.
5. اختبار النص والصور على جهاز Android حقيقي.
6. اختبار مستندات عربية واضحة ومائلة ومنخفضة الإضاءة.
7. مراجعة سياسة الخصوصية وشاشة الموافقة.
8. إنشاء keystore خاص بالتوقيع وحفظه بأمان.
9. إنشاء Release AAB من Android Studio.
10. رفع AAB واختبار النسخة عبر Google Play Internal testing قبل النشر العام.

> لا تعتبر النسخة جاهزة للنشر العام قبل تنفيذ الاختبارات والخطوات أعلاه.
